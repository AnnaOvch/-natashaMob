import Foundation

struct Company: Codable {
    var _id: String?
    var name: String?
}
struct CompanyDict: Codable {
    var company: Company
}
