import Foundation

var mainUser: User?

struct User: Codable{
    var email: String?
    var password: String?
    var token: String?
    var id: String?
    var activeHours: ActiveHours?
    var companyId: String?
    var position: String?
    var name: String?
    var sick: Bool?
    var team: String?
}

struct ActiveHours: Codable{
    var from: Int?
    var to: Int?
}

struct UserDict: Codable {
    var user: User
}

