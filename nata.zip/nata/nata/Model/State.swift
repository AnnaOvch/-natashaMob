import Foundation

struct State: Codable {
    var temperatureBuild: Double?
    var temperatureBody: Double?
    var timeOfActivity: [Int64]?
    var pressure: [Double]?
}
