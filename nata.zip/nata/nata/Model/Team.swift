import Foundation

struct Team: Codable {
    var _id: String?
    var title: String?
    var appointment: String?
    var size: Int?
    
}

struct TeamDict: Codable {
    var team: Team
    
}
