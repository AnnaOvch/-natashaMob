import Foundation
import Alamofire

class Network {
    static let shared = Network()
    private init(){}
    
    
    func getTeam(request: ApiRouter,completion: @escaping (Result<Team,ApiError>)->Void) {
        AF.request(String(request.getApiUrl()), method: .get).responseData { response in
            switch response.result {
            case .success(let teamData):
                do {
                    let teamDict = try JSONDecoder().decode(TeamDict.self, from: teamData)
                    let team = teamDict.team
                    completion(.success(team))
                } catch  {
                    completion(.failure(ApiError.problemWithTeam))
                }
            case .failure(_):
                completion(.failure(ApiError.problemWithTeam))
            }
        }
        
    }
    
    func getState(request: ApiRouter,completion: @escaping (Result<State,ApiError>)->Void) {
        guard let token = mainUser?.token else {return}
        let headers:HTTPHeaders = ["Authorization":token]
        
        guard let mainUser = mainUser else {return}
        guard let id = mainUser.id else {return}
        
        AF.request(String(request.getApiUrl() + id), method: .get, headers: headers).validate(statusCode:200..<300).responseData { (response) in
            switch response.result {
            case .success(let stateData):
                do {
                    let state = try JSONDecoder().decode(State.self, from: stateData)
                    completion(.success(state))
                } catch  {
                    completion(.failure(ApiError.problemWithState))
                }
            case .failure(_):
                completion(.failure(ApiError.problemWithState))
            }
        }
    }
    
    
    func getProfile(request:ApiRouter,completion: @escaping(Result<User,ApiError>)->Void){
        guard let token = mainUser?.token else {return}
        let headers:HTTPHeaders = ["Authorization":token]
        AF.request(String(request.getApiUrl()),method: .get, headers: headers).responseData {(response) in
            switch response.result {
            case .success(let userFromBack):
                
                do {
                    
                    guard let userDict =  try? JSONDecoder().decode(UserDict.self, from: userFromBack) else {
                        completion(.failure(ApiError.problemWithProfileOnBack))
                        return
                    }
                    
                    let user = userDict.user
                    completion(.success(user))
                    
                } catch  {
                    completion(.failure(ApiError.problemWithProfileOnBack))
                }
            case .failure(_):
                completion(.failure(ApiError.problemWithProfileOnBack))
            }
            
        }
        
    }
    
    func signInUser(user:User,request:ApiRouter, completion: @escaping (Result<User,ApiError>)->Void) {
        AF.request(String(request.getApiUrl()), method: .post, parameters: ["email":user.email ?? "","password":user.password ?? ""], encoding: JSONEncoding.default).validate(statusCode: 200..<300).responseData { (response) in
            
            switch response.result {
                
            case .success(let userFromBack):
                
                do {
                    
                    guard let result = try JSONSerialization.jsonObject(with: userFromBack, options: [.allowFragments]) as? [String:String] else { return }
                    if  let token = result["token"],let id = result["id"] {
                        let myUser = User(email: user.email, token: token,id:id)
                        mainUser = myUser
                        DispatchQueue.main.async {
                            completion(.success(myUser))
                        }
                        
                    } else {
                        completion(.failure(ApiError.authenticationError))
                    }
                } catch {
                    completion(.failure(ApiError.authenticationError))
                }
                
                
            case .failure(_):
                if let httpStatusCode = response.response?.statusCode {
                    switch httpStatusCode {
                    case 401:
                        completion(.failure(ApiError.noSuchUser))
                    default:
                        break
                    }
                } else {
                    completion(.failure(ApiError.unknownError))
                }
            }
        }
    }
    
    
    
    func getCompany(id:String,request:ApiRouter, completion: @escaping (Result<String,ApiError>)->Void) {
        AF.request(request.getApiUrl()+id).validate(statusCode:200..<300).responseData { (response) in
            switch response.result {
            case .success(let companyData):
                do {
                    let companyDict = try JSONDecoder().decode(CompanyDict.self, from: companyData)
                    let company = companyDict.company
                    let name = company.name ?? ""
                    completion(.success(name))
                    
                } catch  {
                    completion(.failure(ApiError.problemWithCompany))
                }
            case .failure(_):
                completion(.failure(ApiError.problemWithCompany))
                
            }
        }
    }
    
    
    
    func patchProfile(url:String,completion: @escaping (Result<Bool,ApiError>)->Void) {
        guard let token = mainUser?.token else {return}
        let headers:HTTPHeaders = ["Authorization":token]
        AF.request(url,method: .patch,headers: headers).validate(statusCode:200..<300).responseData { (response) in
            switch response.result {
            case .success(_):
                completion(.success(true))
            case .failure(_):
                completion(.failure(.problemWithPatchUser))
                
            }
        }
    }
    
}


