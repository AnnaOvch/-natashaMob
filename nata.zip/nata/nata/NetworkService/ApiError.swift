import Foundation

enum ApiError:Error {
    case noSuchUser
    case authenticationError
    case unknownError
    case problemWithProfileOnBack
    case problemWithCompany
    case problemWithPatchUser
    case problemWithState
    case problemWithTeam
    var description: String {
        switch  self  {
        case .noSuchUser:
            return "No such user registered"
        case .authenticationError:
            return "Error in authentication"
        case .unknownError:
            return "Unknown error occured"
        case .problemWithProfileOnBack:
            return "Error with profile on back occurred"
        case .problemWithCompany:
            return "Error in extractong company"
        case .problemWithPatchUser:
            return "Problem with ediing profile"
        case .problemWithState:
            return "Problem with state info occured"
        case .problemWithTeam:
            return "There is a problem with team occured"
        }
    }
}
