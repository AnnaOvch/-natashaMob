
import Foundation

enum ApiRouter {
    static let baseURL = "https://we-work.herokuapp.com/"
    case login
    case profile
    case company
    case patchProfile
    case state
    case team
    func getApiUrl()->String {
        switch self{
        case .login:
            return ApiRouter.baseURL+"user/login"
        case .company:
            return ApiRouter.baseURL + "company/"
        case .patchProfile:
            return ApiRouter.baseURL + "user/info/"
        case .state:
            return ApiRouter.baseURL + "iot/"
        case .team:
             guard let teamId  = mainUser?.team else {return ""}
            return ApiRouter.baseURL + "team/info/\(teamId)"
        case .profile:
            guard let id  = mainUser?.id else {return ""}
            return ApiRouter.baseURL + "user/\(id)"

        }
    }
}
