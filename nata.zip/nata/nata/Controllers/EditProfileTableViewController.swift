
import  Alamofire
import UIKit

class EditProfileTableViewController: UITableViewController,Validatings {
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var saveBtn: UIBarButtonItem!
    
    @IBOutlet weak var sickLabel: UILabel!
    
    @IBOutlet weak var sickSwicth: UISwitch!
    
    var email:String?
    var name:String?
    var surname:String?
    
    var boolSick:Bool?
    
    
    weak var delegate: SaveEditProfileProtocol?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.emailTextField.text = email
        self.nameTextField.text = name
        self.lastNameTextField.text = surname
        
        self.sickSwicth.isOn = boolSick ?? false
        self.sickLabel.text = boolSick==true ? "You are sick" : "You are not sick"
        
        emailTextField.addTarget(self, action: #selector(emailTxtNotEmpty), for: .valueChanged)
        nameTextField.addTarget(self, action:  #selector(nameTxtNotEmpty), for: .valueChanged)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        self.view.addGestureRecognizer(tapGesture)
        
    }
    
    @objc func emailTxtNotEmpty() {
        if emailTextField.text?.isEmpty == true {
            saveBtn.isEnabled = false
        }
    }
    @objc func nameTxtNotEmpty() {
        if nameTextField.text?.isEmpty == true {
            saveBtn.isEnabled = false
        }
    }
    
    
    @objc func hideKeyboard(){
        self.view.endEditing(true)
    }
    
    @IBAction func saveButton(_ sender: Any) {
        let newEmail = emailTextField.text ?? ""
        let newName = nameTextField.text ?? ""
        let newLastName = lastNameTextField.text ?? ""
        guard let mainUserId  = mainUser?.id else {return}
        guard  let urlComponents = NSURLComponents(string:  "https://we-work.herokuapp.com/user/info"+mainUserId) else {return}
        let addressStr = "https://we-work.herokuapp.com/user/info/"+mainUserId
        
        let emailToPatch = newEmail
        let nameToPatch = newName
        let lastNameToPatch = newLastName
        let mailCheck = validateEmail(candidate: emailToPatch)
        let nameCheck = validateName(candidate: nameToPatch)
        let lastNameCheck = validateName(candidate: lastNameToPatch)
        if mailCheck == false || nameCheck == false || lastNameCheck == false {
            self.showAlert(alertText: "Check your fields,something is incorrect", alertAction: "ok", handler: nil)
        } else {
            urlComponents.queryItems = [
                URLQueryItem(name: "email", value: emailToPatch),
                URLQueryItem(name: "firstName", value: nameToPatch),
                URLQueryItem(name: "secondName", value: lastNameToPatch),
                URLQueryItem(name: "sick", value: String(sickSwicth.isOn))
            ]
            let url = String(addressStr + "?" + urlComponents.query!)
            
            Network.shared.patchProfile(url: url) { [weak self](result) in
                switch result{
                case .success(let boolResponse):
                    if boolResponse == true {
                        mainUser?.email = emailToPatch
                        mainUser?.name = nameToPatch + " " + lastNameToPatch
                        
                        self?.showAlert(alertText: "Successfully modified", alertAction: "ok") { (alert) in
                            self?.delegate?.didTapSave(email: emailToPatch, name: nameToPatch,ifSick: self?.sickSwicth.isOn, surname:lastNameToPatch)
                            self?.navigationController?.popViewController(animated: true)
                        }
                    }
                case .failure(let error):
                    self?.showAlert(alertText: error.description, alertAction: "ok") { (alert) in
                        self?.navigationController?.popViewController(animated: true)
                    }
                }
            }
        }
    }
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        boolSick?.toggle()
        self.sickLabel.text = sender.isOn == true ? "You are sick" : "You are not sick"
        
    }
    
    
}

extension EditProfileTableViewController:UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}

protocol SaveEditProfileProtocol: class{
    func didTapSave(email:String?,name:String?,ifSick: Bool?,surname:String?)
}
