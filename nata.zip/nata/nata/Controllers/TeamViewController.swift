import UIKit

class TeamViewController: UIViewController, UIScrollViewDelegate {
    
    let activityIndicator = UIActivityIndicatorView()
    
    @IBOutlet weak var myScrollView: UIScrollView!
    
    @IBOutlet weak var nameOfTeam: UILabel!
    @IBOutlet weak var appointment: UILabel!
    @IBOutlet weak var sizeTeam: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myScrollView.delegate = self
        
        
        setUpActivityIndicator()
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        
        for subview in view.subviews where !(view is UIActivityIndicatorView) {
            subview.isHidden = true
        }
        let request = ApiRouter.profile
        Network.shared.getProfile(request: request) { [weak self] (result) in
            switch result {
            case .success(let user):
                mainUser?.team = user.team
                let request = ApiRouter.team
                Network.shared.getTeam(request: request) { result in
                    switch result {
                    case .success(let team):
                        self?.nameOfTeam.text = team.title?.isEmpty == true ? "No name" : team.title
                        self?.appointment.text = team.appointment?.isEmpty == true ? "No appointment" : team.appointment
                        if let teamS = team.size {
                            self?.sizeTeam.text = String(teamS).isEmpty == true ? "No size" : String(teamS)
                        } else {
                            self?.sizeTeam.text = "No size"
                        }
                        
                        
                        for subview in self!.view.subviews where !(self!.view is UIActivityIndicatorView) {
                            subview.isHidden = false
                        }
                        self?.activityIndicator.stopAnimating()
                        
                        
                    case .failure(_):
                        
                        self?.activityIndicator.stopAnimating()
                        
                        self?.view.backgroundColor = .lightGray
                        
                        let myLabel = UILabel(frame: CGRect(x: ((self?.view.frame.width)! - 290)/2, y: ((self?.view.frame.height)! - 70)/2, width: 290, height: 70))
                        myLabel.text = "You are not in a company"
                        
                        myLabel.textAlignment = .center
                        
                        self?.view.addSubview(myLabel)
                        
                    }
                }
            case .failure(_):
                self?.view.backgroundColor = .lightGray
                let rect =  CGRect(origin: CGPoint(x: self?.view.bounds.midX ?? 100, y: self?.view.bounds.midY ?? 100), size: CGSize(width: 50.0, height: 50.0))
                let label = UILabel(frame: rect)
                label.text = "no company"
            }
        }
        
    }
    
    
    func setUpActivityIndicator () {
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.large
        activityIndicator.color = .black
        activityIndicator.frame = CGRect(x: self.view.frame.width/2, y: self.view.frame.height/2, width: 40.0, height: 40.0)
        activityIndicator.isHidden = true
        activityIndicator.center = self.view.center
        self.view.addSubview(activityIndicator)
    }
    
}
