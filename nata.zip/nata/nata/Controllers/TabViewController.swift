import UIKit
import Alamofire

class TabViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
 
    }
    
}
