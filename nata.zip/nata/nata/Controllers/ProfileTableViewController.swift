
import UIKit

class ProfileTableViewController: UITableViewController {
    
    
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var companyLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
    @IBOutlet weak var sickLabel: UILabel!
    

    var boolSick:Bool?
    
    let activityIndicator = UIActivityIndicatorView()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpActivityIndicator()
        
        for subview in view.subviews where !(view is UIActivityIndicatorView) {
            subview.isHidden = true
        }
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        //tableView.isHidden = 
        let request = ApiRouter.profile
        Network.shared.getProfile(request: request) { [weak self](result) in
            
            switch result{
            case .success(let user):
                let request = ApiRouter.company
                Network.shared.getCompany(id: user.companyId ?? "", request: request) { [weak self](result) in
                    switch result{
                    case .success(let companyName):
                        self?.companyLabel.text = companyName
                    case .failure(_):
                        self?.companyLabel.text = "No company registered"
                    }
                }
                
                self?.emailTextField.text = user.email ?? "Add email"
                if user.name?.isEmpty == true {
                    self?.nameTextField.text = "Add name"
                } else {
                     self?.nameTextField.text = user.name
                }
                if user.position?.isEmpty == true {
                     self?.positionLabel.text = "No position registered"
                } else {
                     self?.positionLabel.text = user.position
                }
                self?.sickLabel.text = user.sick == true ? "You are sick" : "You are not sick"
                self?.boolSick = user.sick
                self?.companyLabel.text = user.companyId ?? "No company registered"
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                    for subview in self!.view.subviews where !(self!.view is UIActivityIndicatorView) {
                        subview.isHidden = false
                    }
                    self?.activityIndicator.isHidden = true
                    self?.activityIndicator.stopAnimating()

                }
              
                       
               
            case .failure(let error):
                for subview in self!.view.subviews where !(self!.view is UIActivityIndicatorView) {
                    subview.isHidden = false
                }
                self?.activityIndicator.isHidden = true
                self?.activityIndicator.stopAnimating()
                self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
            }
        }
        
        self.emailTextField.isEnabled = false
        self.nameTextField.isEnabled = false
        
        
    }
    
    func setUpActivityIndicator () {
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.large
        activityIndicator.color = .black
        activityIndicator.frame = CGRect(x: self.view.frame.width/2, y: self.view.frame.height/2, width: 40.0, height: 40.0)
        activityIndicator.isHidden = true
        activityIndicator.center = self.view.center
        self.view.addSubview(activityIndicator)
        
        
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "editSegue" {
            let vc = segue.destination as! EditProfileTableViewController
            vc.delegate = self
            vc.email = self.emailTextField.text
            vc.boolSick = self.boolSick
            let (separName,separSurname) = separateName(name: self.nameTextField.text ?? "")
            vc.name = separName
            vc.surname = separSurname
        }
    }
    

    @IBAction func logOutButton(_ sender: UIBarButtonItem) {
        
        mainUser = nil
        self.dismiss(animated: true, completion: nil)
        
    }
    

}
extension ProfileTableViewController: SaveEditProfileProtocol{
    func didTapSave(email: String?, name: String?,ifSick: Bool?, surname: String?) {
        self.emailTextField.text = email
        self.sickLabel.text = ifSick == true ? "You are sick" : "You are not sick"
        self.boolSick = ifSick
        self.nameTextField.text = name! + " " + surname!
    }
    
 
    func separateName(name:String)->(String,String) {
       let ch = Character(" ")
       let arr = name.split(separator: ch)
        return (String(arr[0]),String(arr[1]))
    }
    
    
    
    
}
