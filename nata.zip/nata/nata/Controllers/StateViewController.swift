

import UIKit

class StateViewController: UIViewController{
    
    
    @IBOutlet weak var buildTemperatureTextField: UILabel!
    
    @IBOutlet weak var bodyTemperatureTextField: UILabel!
    
    @IBOutlet weak var activityTimeTextField: UILabel!
    
    @IBOutlet weak var pressureTextField: UILabel!
    
    let activityIndicator = UIActivityIndicatorView()
    
    
    func setUpActivityIndicator () {
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.large
        activityIndicator.color = .black
        activityIndicator.frame = CGRect(x: self.view.frame.width/2, y: self.view.frame.height/2, width: 40.0, height: 40.0)
        activityIndicator.isHidden = true
        activityIndicator.center = self.view.center
        self.view.addSubview(activityIndicator)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpActivityIndicator()
        for subview in view.subviews where !(view is UIActivityIndicatorView) {
            subview.isHidden = true
        }
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        
        let request = ApiRouter.state
        Network.shared.getState(request: request) { [weak self] (result) in
            switch result {
            case .success(let state):
                self?.buildTemperatureTextField.text = String(format: "%.2f", state.temperatureBuild ?? "")
                
                self?.bodyTemperatureTextField.text = String(format:"%.2f",state.temperatureBody ?? "")
                
                let arr = self?.returnFromMilSecToStr(num: state.timeOfActivity ?? []) ?? ("","")
                
                self?.activityTimeTextField.text = arr.0 + "-" + arr.1
                
                let arrPressure = self?.roundPressure(arr: state.pressure ?? []) ?? ("","")
                
                self?.pressureTextField.text = arrPressure.0 + "/" + arrPressure.1
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                    for subview in self!.view.subviews where !(self!.view is UIActivityIndicatorView) {
                        subview.isHidden = false
                    }
                    self?.activityIndicator.isHidden = true
                    self?.activityIndicator.stopAnimating()
                    
                }
                
            case .failure(let error):
                
                self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                
            }
        }
    }
    
    
    
}

extension StateViewController {
    func returnFromMilSecToStr(num:[Int64])->(String,String) {
        let date1 = Date(millis: num[0])
        let date2 = Date(millis: num[1])
        let calendar = Calendar.current
        let hour1 = calendar.component(.hour, from: date1)
        let minutes1 = calendar.component(.minute, from: date1)
        let hour2 = calendar.component(.hour, from: date2)
        let minutes2 = calendar.component(.minute, from: date2)
        
        var result1 = printH(hour: hour1, min: minutes1)
        
        if result1.0.count==1 {
            result1.0 = "0" + result1.0
        }
        
        if result1.1.count==1 {
            result1.1 = "0" + result1.1
        }
        
        
        let resultStr1 = result1.0 + ":" + result1.1
        
        var result2 = printH(hour: hour2, min: minutes2)
        
        if result2.0.count==1 {
            result2.0 = "0" + result2.0
        }
        
        if result2.1.count==1 {
            result2.1 = "0" + result2.1
        }
        
        let resultStr2 = result2.0 + ":" + result2.1
        
        return (resultStr1,resultStr2)
        
    }
    
    
    func printH(hour:Int,min:Int)->(String,String) {
        var time = ((hour*60 + min)-3*60)
        if time<0 {
            time += 1440
        }
        let min = String(time%60)
        let h = String(time/60)
        return (h,min)
    }
    
    func roundPressure(arr:[Double]) -> (String,String) {
        let first = Double(round(1000*arr[0])/1000).rounded()
        let second =  Double(round(1000*arr[1])/1000).rounded()
        return (String(Int(first)), String(Int(second)))
    }
}
