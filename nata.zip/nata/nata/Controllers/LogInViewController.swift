import UIKit
import Alamofire

class LogInViewController: UIViewController,Validatings {

    @IBOutlet weak var emailTextField: myTextField!
    @IBOutlet weak var passwordTextField: myTextField!
    
    let activityIndicator = UIActivityIndicatorView()
    
    func setUpActivityIndicator () {
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.large
        activityIndicator.color = .black
        activityIndicator.frame = CGRect(x: self.view.frame.width/2, y: self.view.frame.height/2, width: 40.0, height: 40.0)
        activityIndicator.isHidden = true
        activityIndicator.center = self.view.center
        self.view.addSubview(activityIndicator)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        for subview in self.view.subviews {
            subview.isHidden = false
        }
        activityIndicator.isHidden = true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpActivityIndicator()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(didTap))
        view.addGestureRecognizer(tap)
        

    }
    @IBAction func logInButton(_ sender: Any) {
        guard  let email = emailTextField.text else {return}
        guard let password = passwordTextField.text else {return}
        guard email.count>0,password.count>0 else {
            self.showAlert(alertText: "Enter all fields", alertAction: "ok", handler: nil)
            return
        }
        
        let mailCheck = validateEmail(candidate: email)
        let passCheck = validatePassword(candidate: password)
        if mailCheck == false{
            self.showAlert(alertText: "Check your mail, it is incorrect", alertAction: "ok", handler: nil)
            return
        }
        if passCheck == false {
            self.showAlert(alertText: "Password must be more than 5 characters", alertAction: "ok", handler: nil)
            return
        }
        if passCheck&&mailCheck == true {
            for subview in view.subviews where !(view is UIActivityIndicatorView) {
                subview.isHidden = true
            }
            
            activityIndicator.isHidden = false
            activityIndicator.startAnimating()
            
            let request = ApiRouter.login
            let user = User(email: email, password: password)
            Network.shared.signInUser(user: user, request: request) { [weak self](result) in
                switch result{
                case .success(_):
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        
                        self?.activityIndicator.stopAnimating()
                        self?.activityIndicator.isHidden = true
                        self?.performSegue(withIdentifier: "segueToTab", sender: self)
                      
                    }
                    
                    
                case .failure(let error):
                    
                    
                    self?.activityIndicator.stopAnimating()
                    
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                    
                    for subview in self!.view.subviews where !(self!.view is UIActivityIndicatorView) {
                        subview.isHidden = false
                    }
                    
                    self?.activityIndicator.isHidden = true
                }
            }
            
        }
    }
    
    @objc func didTap() {
        self.view.endEditing(true)
    }

}
extension LogInViewController:UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
