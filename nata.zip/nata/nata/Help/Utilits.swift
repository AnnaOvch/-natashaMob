

import UIKit

@IBDesignable class myTextField: UITextField {
    @IBInspectable var corner: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = true
        }
    }
    @IBInspectable var brdColor: UIColor?{
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
            
        }
    }
    
    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
     
    @IBInspectable var leftPadding: CGFloat {
        get {
            return (self.leftView?.frame.width)!
        }
        set {
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: newValue, height: self.frame.size.height))
            self.leftView = paddingView
            self.leftViewMode = .always
        }
    }
}

protocol Validatings {
    func validateEmail(candidate: String) -> Bool
    func validateName(candidate: String)->Bool
    func validatePassword(candidate:String)->Bool
    
}
extension Validatings {
     func validateEmail(candidate: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
           return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: candidate)
       }
    
    func validateName(candidate: String)->Bool {
        if candidate.isEmpty || candidate.count==1 || candidate.components(separatedBy: " ").count >= 2 {
            return false
        }
        return true
    }
    func validatePassword(candidate:String)->Bool {
        if candidate.count <= 5 {
            return false
        }
        return true
    }
}

extension UIViewController {
    func showAlert(alertText : String, alertAction : String?, handler:((UIAlertAction) -> Void)?) {
           var completion: ((UIAlertAction) -> Void)? = nil
           if let handler = handler {
               completion = handler
           }
           let alert = UIAlertController(title: alertText, message: nil, preferredStyle: .alert)
           if let action = alertAction {
               alert.addAction(UIAlertAction(title: action, style: .default, handler: completion))
           }
           
           self.present(alert, animated: true, completion: nil)
           
       }
    func hideVC(vc:UIViewController) {
        
            for subview in vc.view.subviews where !(vc.view is UIActivityIndicatorView) {
                subview.isHidden = false
            }
        
    }
    
       
}

extension Date {

    func toMillis() -> Int64! {
        return Int64(self.timeIntervalSince1970 * 1000)
    }

    init(millis: Int64) {
        self = Date(timeIntervalSince1970: TimeInterval(millis / 1000))
        self.addTimeInterval(TimeInterval(Double(millis % 1000) / 1000 ))
    }

}

